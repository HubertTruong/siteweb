# Beaucoup trop de mots

devops project

## Running Locally

just run ```start.sh```


or with docker
```

$ cd /server
$ docker-compose build 
$ docker-compose up -d 

```
