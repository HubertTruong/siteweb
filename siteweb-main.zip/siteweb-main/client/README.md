# Beaucoup trop de mots

Welcome to Beaucoup trop de mots, a React app that tests your vocabulary skills by challenging you to solve thirty-two Wordles at once! In this game, you have 37 guesses to solve all 32 words. A new word is available each day to solve.

## Running Locally

With npm

```
$ npm install
$ npm start
```

Or with docker-compose

```
$ docker-compose up --build
```